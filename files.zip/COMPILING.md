# Compilando o CISIS (UTF-8): Linux e Windows

## O que foi verificado e o que não foi

| Alvo | Estado |
|---|---|
| Linux 32 e 64 bits, variantes `ffi1660` e `bigisis` | **Compila e passa 21/21 testes** (`smoke_test.sh`): `mx`, `wxis`, `ifkeys`, `crunchif`, `crunchmf`, `retag`, `i2id`, `id2i` |
| Linux com `char` com sinal (`./build_linux.sh -s`, como o BCC55) | **21/21** também: o código UTF-8 não depende de `-funsigned-char` |
| Windows, Borland C++ 5.5, `mx.exe` e `wxis.exe` | **Compilou no seu Windows**: 0 erros, 342 avisos (175 distintos) |
| Windows, Borland C++ 5.5, utilitários (`build_windows_tools_bcc55.bat`) | **Gerado, nunca executado** |
| Windows, MinGW/MSYS2 | Ainda não confiável (ver abaixo) |

## Os programas do ABCD

| Programa | Linux (UTF-8) | Windows |
|---|---|---|
| `mx`, `wxis` | ✔ testado | ✔ compilado por você |
| `ifkeys`, `crunchif`, `crunchmf`, `retag`, `i2id`, `id2i` | ✔ testado (depois do patch `cisis_fixes_utf8.patch`) | bat gerado, **não testado** |
| `pdftohtml` | **não é do CISIS** (é do Poppler/Xpdf) | use `poppler-utils` no Linux; no Windows, um build do Poppler. Fora deste projeto |

Os `.mak` de `crunchif`, `crunchmf`, `retag`, `i2id`, `id2i`, `mxcp`, `msrt`, `mxf0`, `ifload` e `ifmerge` **não existiam** no repositório UTF-8 (a BIREME tem 53 `.mak`, o repositório UTF-8 só 21; os `.c` estavam lá). O patch os restaura da BIREME já com `ciutf8.o` na ligação. Sem isso a ligação falha com `undefined reference to loaductb_utf8`. `tools/fix_mak_utf8.py` faz o mesmo para qualquer outro `.mak` da BIREME.

## Linux

```bash
sudo apt install build-essential            # gcc e make
sudo apt install gcc-multilib libc6-i386    # só para 32 bits

./build_linux.sh                  # 32 bits, ffi1660, mx + wxis   -> dist/linux32/ffi1660/
./build_linux.sh -t "mx wxis ifkeys crunchif crunchmf retag i2id id2i"   # o conjunto do ABCD
./build_linux.sh -a 64            # 64 bits (usa -no-pie)
./build_linux.sh -v bigisis       # registros grandes / arquivos > 2 GB
./build_linux.sh -s               # char com sinal (como o BCC55)
./build_linux.sh -u 0 -v isis1660 # build ANSI
./smoke_test.sh dist/linux32/ffi1660
```

Objetos em `build/`, binários em `dist/`; o repositório não é sujado. O banner do `mx` mostra o build, por exemplo `.../F/M/1048576/16/60/I/UTF-8`.

### 32 ou 64 bits?
**32 bits é o padrão.** No modo `SIXTY_FOUR`, `LONGX` é `int` e o compilador de formatos guarda ponteiros nele (`next`/`m_add` de `FMT_CODE`, ~150 conversões em `cifm1.c`, `cifm2.c`, `cifm3.c`, `wtrun.c`, `cib72.c`). Um executável PIE (padrão do gcc atual) dá segfault em `fmt_chadd`; o 64 bits só funciona com `-no-pie` (o script já aplica) e depende de o heap ficar abaixo de 4 GB. O conserto real é trocar esses campos por `intptr_t`. Rodar o 32 bits num Ubuntu 64 bits exige `libc6-i386`.

## Defeitos encontrados e corrigidos (patch `cisis_fixes_utf8.patch`)

1. **`citrm.c`: o fim do dicionário (`highv`) era `0x7F` fora do Windows.** Qualquer chave UTF-8 com byte acima de `0x7F` (russo, hebraico, acentos...) comparava como "depois do fim", e a leitura sequencial do dicionário parava no último termo ASCII. Efeitos medidos: `ifkeys db` listava 7 dos 11 termos; **buscas com truncamento falhavam** (`ПРИВ$`, `שלו$` → 0 resultados, agora 1); a lista de termos do OPAC (`processar_ifkeys.php`) ficava incompleta. Acontecia também nos binários pré-compilados do repositório. No Windows (`PC=1`) já era `0xFF`, então não afeta o BCC55. Correção: `#if PC || UTF8` (0xFF nunca ocorre em UTF-8).
2. **`ifkeys.c`: `from=`/`to=` e `key1=`/`key2=` davam segfault em UTF-8.** O código fazia `*k1p = uppercase_utf8(p)`, gravando um ponteiro na memória de uma string literal e sem pular o prefixo `from=`. Reproduzido também no binário pré-compilado do repositório. Corrigido copiando o valor para `k1`/`k2` e passando para maiúsculas.
3. **`.mak` sem `ciutf8.o`** (ver acima).

## Comportamento que não é defeito

- `crunchmf` e `crunchif` **sem `target=` convertem para o formato da OUTRA plataforma** (padrão: `pc` no Linux, `linux` no Windows). É o que `db_convert_crunchmf.php` do ABCD usa. Para compactar na mesma plataforma, use `target=linux` (no Linux) ou `target=pc` (no Windows).
- **`-DINCLOADX=1` é necessário para UTF-8 multilíngue.** Sem ele o CISIS ignora `uctab=`/`actab=` do `.par` e palavras fora do latim básico não são indexadas nem achadas (medido: `привет`, `שלום` → 0 resultados; com a flag e as tabelas → 1). O `build_linux.sh` e os `.bat` gerados já passam a flag; os `.bat` oficiais não passam.
- O CISIS só lê as chaves `uctab=` e `actab=` do `.par` (em `cisisx.c`), não `isisac.tab=`/`isisuc.tab=`.
- `isisactab_utf8.tab` do ABCD não tem hebraico; `tests/isisactab_utf8_he.tab` acrescenta as 27 letras (U+05D0..U+05EA).
- O FST precisa de `mpu` (`1 4 mpu,v1`), senão os termos não vão para maiúsculas.
- Termos truncados com acento (`ÁGU$`) não acham `AGUA` indexado com `mpu` (o acento do prefixo não é removido na consulta). Observado, não investigado.

## Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\find_compilers.ps1
build_windows_bcc55.bat            # mx.exe e wxis.exe  -> dist\windows32\ffi\
build_windows_tools_bcc55.bat      # utilitarios        -> dist\windows32\ffi\   (gerado por tools/gen_bcc_tools.py)
```

- Os `.exe` oficiais foram feitos com BCC55 **sem** `-K`: `char` com sinal. Os testes Linux com `-s` (char com sinal) passam 21/21.
- Os `.bat` oficiais (`CISIS_UNI_Win\projects`) só constroem `mx` e `wxis`.
- MinGW compila (com `alloc.h`, `sys\stat.h`, sockets, `_rtl_*`, `lock`/`unlock`, `O_DENYNONE`, `MAXPATH` remendados), mas o `wxis.exe` falhou com `Invalid operand class` em `replace(s(cat(...)))`. Não use até testar num Windows real.

## Avisos do compilador

**BCC55** (175 distintos): 154 são estilo (`W8004` atribuído e não usado 77, `W8012` comparação com/sem sinal 57, `W8057` parâmetro não usado 22) e 6 são `W8066`/`W8008`. Os que merecem revisão:

- `cifm2.c:604,633` (`W8075`): `strlen_UTF8`/`skipchar_UTF8` atribuem `const char *` a `unsigned char *` (falta cast).
- `easyfc.c:171-197` (`W8065`, 6x): `open/close/read` sem protótipo (falta `#include <io.h>`).
- `cisisx.c:2539` (`W8041`): `LSEEK64(fd,-sizeof(IFPCTRL),SEEK_CUR)` nega um `size_t`; com offsets de 64 bits num `size_t` de 32 bits isso vira um deslocamento positivo gigante. Revisar nas variantes grandes (bigisis) no Windows 32.
- `cifst.c:1534` (`W8068`): `fst_fbsiz > ALLOMAXV` é sempre falso (a proteção nunca dispara).
- `cifm3.c:2258,3505` (`W8019`) e `cisisx.c:229` (`W8053`, `sleep` obsoleto): inofensivos.

**gcc 32 bits com `-Wall`** (~3.500 ocorrências): quase tudo é ruído (`-Wswitch` 2145, `-Wmissing-braces` 382, `-Wpointer-sign` 362, `-Wattributes` 290). Os que podem esconder defeito são ~70 locais: `-Wformat` 30, `-Wformat-overflow` 10, `-Wint-conversion` 7, `-Wimplicit-function-declaration` 7, `-Wformat-security` 4, `-Wmaybe-uninitialized` 3, `-Wstringop-overflow` 1, `-Wsequence-point` 1. Plano sugerido: triar esses ~70, corrigir, e então ligar `-Werror=` só para essas categorias, para impedir regressões sem brigar com o ruído.

## Programas que ainda não compilam em UTF-8

`ifupd mxtb mz splitm b7 chkterm decs9a decs9b decsex ifp1 mdlmf mxgw wtrig1 wtrig2 aotmsa2` usam `isisuctab`/`isiswctab` diretamente (não declarados no modo UTF-8) e precisam de porte de código. Nenhum está na lista do ABCD. Com `-u 0` todos compilam.

## Duas árvores de fonte

`CISIS_UNI_Win/sources` **não é o original da BIREME**: o original (github.com/bireme/cisis) não tem `UTF8` em `cisis.h` nem `ciutf8.c`. É uma árvore já modificada (UTF-8, v6.0a) que gerou os `.exe` oficiais, e diverge da raiz (por exemplo `cifm3.c:580` com `p++;q++;` avançando `q` duas vezes em `fmt_type_pattern`, `MAXREFS` 32 contra 16, `EXE_REC_SIZE` com `3*`). Mantenha-a numa branch ou pasta `legacy/`, não a apague.

## Bug conhecido do WXIS: parm desconhecido

`xis_exec.c`, `exeParm()`: `cplIdentifier()` devolve `ATVALUE_LIST_QTT` para nomes de parm inexistentes e o código faz `atValueParm[...]` com esse índice (uma posição além do array). Nos `.exe` oficiais isso derruba o WXIS com *page fault* (o `crear_registro.xis` do ABCD tinha `MAX_TMP_STRING`). Correção, antes de `parmIndex = atValueParm[...]`:
```c
if (cmd->attributeList[ATTRIBUTE_NAME].atValue >= ATVALUE_LIST_QTT) return; /* parm desconhecido: ignora */
```
Ainda não confirmada recompilando um `.exe` Windows.
