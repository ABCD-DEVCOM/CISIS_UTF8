/* ------------------------------ wtz.h ------------------------------------- */

#undef MAXPRMS1

#undef TAG1   
#undef TAG2   
#undef TAG3   
#undef TAG4   
#undef TAG5   
#undef TAG33 

#undef TAG34 
#undef TAG35 

#undef MAXPARMWIDTH

#undef VECTEL

#undef LISTA

