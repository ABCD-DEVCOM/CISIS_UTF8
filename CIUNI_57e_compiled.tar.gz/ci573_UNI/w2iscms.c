        /* init similarity computation for document only components */
        float Wsomaq=0; /* init sum of squares for document terms */
	    float somaprod,somaq,simil; /* computation variables */

        /* init document most similar hit */
        float collapsesim1=0.0;
        LONGX collapsemfn1=0;
        LONGX collapsehit1=0;

