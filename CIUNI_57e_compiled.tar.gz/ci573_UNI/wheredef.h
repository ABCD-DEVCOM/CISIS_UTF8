#define VERSION_PC    0
#define VERSION_UNIX  1
#if VERSION_UNIX
#define O_TEXT        0x4000
#define O_DENYNONE    0
#define O_BINARY      0
#endif
