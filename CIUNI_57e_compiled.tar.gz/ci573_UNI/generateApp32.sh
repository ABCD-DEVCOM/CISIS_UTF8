rm nohup.out
rm *.o
rm mk*.sh
rm xmk.sh
rm xls
make -f mx.mak
rm *.o
rm -fr utl
rm -fr wxis
sh ./makemakeApp32.xsh
